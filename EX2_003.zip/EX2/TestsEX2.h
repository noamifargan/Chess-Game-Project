//
// Created by Ron on 22/11/2020.
//

#ifndef CPP_TESTSEX2_H
#define CPP_TESTSEX2_H


class TestsEX2 {

};


#endif //CPP_TESTSEX2_H
