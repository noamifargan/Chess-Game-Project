//
// Created by Ron on 24/11/2020.
//

#ifndef CPP_GAMEPLAY_H
#define CPP_GAMEPLAY_H


class GamePlay {
    public:
        GamePlay();
        void Move(string);
        int convertLetter(char);
        Board currBoard();
        int getTurns();
    private:
        Board n_Board;
        int turns;
};


#endif //CPP_GAMEPLAY_H
