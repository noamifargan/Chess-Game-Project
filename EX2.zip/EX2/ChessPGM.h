//
// Created by Ron on 22/11/2020.
//

#ifndef CPP_CHESSPGM_H
#define CPP_CHESSPGM_H

class ChessPGM {

};
#endif //CPP_CHESSPGM_H
