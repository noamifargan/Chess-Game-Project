/*
Student: Ron Vaknin
ID: 305769440
Assignment no.@
Program: TestsEX2.cpp
22/11/2020
*/

//
// Created by Ron on 22/11/2020.
//

#include "TestsEX2.h"
#include <string>
#include <iostream>
using namespace std;
int main()
{

    string board_all[8][8];
    for (int row = 0; row < 8 ; ++row) {
        for (int col = 0; col < 8; col++) {
            board_all[row][col] = ".";
        }
    }
    for (int col = 0; col < 8; col++) {
        board_all[6][col] = "P";
    }
    for (int col = 0; col < 8; col++) {
        board_all[1][col] = "p";
    }
//    board_all[7][1] = "N";
//    board_all[7][6] = "N";
//    board_all[0][1] = "n";
//    board_all[0][6] = "n";
//    board_all[7][0] = "R";
//    board_all[7][7] = "R";
//    board_all[0][0] = "r";
//    board_all[0][7] = "r";
//
//    board_all[7][2] = "B";
//    board_all[7][5] = "B";
//
//    board_all[0][2] = "b";
//    board_all[0][5] = "b";
//    //set queen and king black's
//    board_all[7][3] = "Q";
//    board_all[7][4] = "K";
//    //set queen and king white's
//    board_all[0][3] = "q";
//    board_all[0][4] = "k";
//
//    string** curr_b=**board_all;

    for (int row = 8-1; row >= 0 ; --row) {
        cout << row+1 << " ";
        for (int col = 0; col < 8; ++col) {
            cout << board_all[row][col] << " ";
        }
        cout << endl;
    }
    cout << "  A B C D E F G H";

    return 0;
}
