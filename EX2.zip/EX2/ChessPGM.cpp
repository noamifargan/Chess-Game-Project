/*
Student: Ron Vaknin
ID: 305769440
Assignment no.2
Program: ChessPGM.cpp
22/11/2020
*/


#include "ChessPGM.h"
#include <iostream>
#include "Board.h"
#include "Pieces.h"
#include "GamePlay.h"
#include <string>
using namespace std;

int main(){
    GamePlay Match;
    //Match.currBoard().printBoard();
//    Match.currBoard().SetPBoard(1,4,'p');
    //Match.Move("D1 A4");
    Match.currBoard().SetPBoard(4,2,'n');
    Match.Move("D1 D6");
    Match.currBoard().printBoard();
    Match.Move("D6 C5");
    Match.currBoard().printBoard();
    //Match.currBoard().printBoard();
   // Match.Move("C4 C4");
    //Match.Move("C5 G1");
    //Match.Move("C4 F4");

//    Match.Move("G8 A8");

    //cout << "Turn Count: "<<Match.getTurns()<< endl;
    //Match.currBoard().printBoard();


//    Match.currBoard().SetPBoard(2,1,'p');
    //Match.Move("A4 E4");
   // Match.currBoard().printBoard();
    //Match.Move("A4 D1");
//    //cout << "Turn Count: "<<Match.getTurns()<< endl;
//    Match.currBoard().printBoard();

//    Match.Move("E6 G3");
//    Match.currBoard().printBoard();
//    Match.Move("G3 D1");
//    Match.currBoard().printBoard();
//    Match.Move("D1 G3");
    return 0;
}