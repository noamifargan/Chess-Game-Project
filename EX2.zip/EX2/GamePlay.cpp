/*
Student: Ron Vaknin
ID: 305769440
Assignment no.2
Program: GamePlay.cpp
24/11/2020
*/

//
// Created by Ron on 24/11/2020.
//
#include <string>
#include "Board.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include "GamePlay.h"
#include "Pieces.h"
using namespace std;
#define IllegalErr cerr << "Illegal move; please enter a move:"<<endl;
#define InvalidErr cerr << "Invalid input; please enter a move:"<<endl;

GamePlay::GamePlay():n_Board(),turns(1) {

}

Board GamePlay::currBoard()
{
    return n_Board;
}
void GamePlay::Move(string move_command) {
    ///
    ///HERE CHECK VALID INPUT/// IMAG.
    //
    int src_row=(move_command[1]- '0')-1,src_col=convertLetter(move_command[0])-1;//contain the x,y of the source player want to move
    int dest_row=(move_command[4]- '0')-1,dest_col=convertLetter(move_command[3])-1;//contain the x,y of the destination player want to move
//    char src_val =(n_Board.GetBoard()[src_row][src_col]);
//    char dest_val = (n_Board.GetBoard()[dest_row][dest_col]);
    Pieces chk(n_Board.GetBoard(), turns);
    if (chk.MvPiece(src_row,src_col,dest_row,dest_col))
    {
        n_Board.GetBoard()[dest_row][dest_col] = n_Board.GetBoard()[src_row][src_col];
        n_Board.GetBoard()[src_row][src_col] = '.';
    }
    else
    {
        IllegalErr;
        return;
    }

//    cout << src[0]<<""<< src[1]<< endl;
//    cout << dest[0] << "" << dest[1];

    turns++;
    return;
}
int GamePlay::convertLetter(char c){
    switch (c)
    {
        case 'A':
            return 1;
        case 'B':
            return 2;
        case 'C':
            return 3;
        case 'D':
            return 4;
        case 'E':
            return 5;
        case 'F':
            return 6;
        case 'G':
            return 7;
        case 'H':
            return 8;
        default:
            printf("NOT A VALID NUCLEIC ACID Char");
    }
    return 0;
}
int GamePlay::getTurns(){return turns;}