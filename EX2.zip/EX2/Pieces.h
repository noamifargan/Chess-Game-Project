//
// Created by Ron on 24/11/2020.
//

#ifndef CPP_PIECES_H
#define CPP_PIECES_H
#include <string>
#include <iostream>
using namespace std;
class Pieces {
    public:
        Pieces(char**, int);
        bool MvPiece(int,int,int,int);
        bool King();
        bool Queen();
        bool Rook();
        bool Bishop();
        bool Knight();
        bool Pawn();
        bool whosTurn();
    private:
        int turns;
        char** curr_board;
        char src_val,dest_val;
        int src_row,src_col,dest_row,dest_col;
        char** kingScan;
        bool castling;

};


#endif //CPP_PIECES_H
